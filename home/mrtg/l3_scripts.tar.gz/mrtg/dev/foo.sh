#! /bin/sh
./RouterIfStats2.sh | ssh
#./RouterIfStats.sh 10001 | telnet -e '&' Stdout.txt 2> Stderr.txt
