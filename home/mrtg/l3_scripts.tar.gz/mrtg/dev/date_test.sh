#! /bin/sh
echo `date` >> /tmp/date.txt
sleep 30
echo `date` >> /tmp/date.txt
